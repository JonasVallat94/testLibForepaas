import setuptools

setuptools.setup(
    name="example-package-YOUR-USERNAME-HERE",
    version="0.0.1",
)